CREATE TABLE `ads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(256) NOT NULL,
	`type` enum('image','video','carousel','story') NOT NULL DEFAULT 'image',
	`status` enum('draft','active','paused','archived') NOT NULL DEFAULT 'draft',
	`mediaUrl` text,
	`headline` varchar(256),
	`body` text,
	`callToAction` varchar(64),
	`destinationUrl` text,
	`impressions` bigint NOT NULL DEFAULT 0,
	`clicks` bigint NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `analytics_snapshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` int NOT NULL,
	`userId` int NOT NULL,
	`date` timestamp NOT NULL,
	`impressions` bigint NOT NULL DEFAULT 0,
	`clicks` bigint NOT NULL DEFAULT 0,
	`conversions` bigint NOT NULL DEFAULT 0,
	`spend` decimal(12,2) NOT NULL DEFAULT '0.00',
	`ctr` decimal(6,4) DEFAULT '0.0000',
	`cpc` decimal(10,4) DEFAULT '0.0000',
	`roas` decimal(10,4) DEFAULT '0.0000',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analytics_snapshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `billing_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('topup','spend','refund') NOT NULL,
	`amount` decimal(12,2) NOT NULL,
	`description` text,
	`status` enum('pending','completed','failed') NOT NULL DEFAULT 'completed',
	`paymentMethod` varchar(64),
	`referenceId` varchar(128),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `billing_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `campaigns` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(256) NOT NULL,
	`description` text,
	`objective` enum('awareness','traffic','engagement','leads','sales') NOT NULL DEFAULT 'awareness',
	`status` enum('draft','active','paused','completed','archived') NOT NULL DEFAULT 'draft',
	`platform` enum('meta','tiktok','youtube','all') NOT NULL DEFAULT 'meta',
	`budget` decimal(12,2) NOT NULL DEFAULT '0.00',
	`spent` decimal(12,2) NOT NULL DEFAULT '0.00',
	`startDate` timestamp,
	`endDate` timestamp,
	`targetAudience` text,
	`impressions` bigint NOT NULL DEFAULT 0,
	`clicks` bigint NOT NULL DEFAULT 0,
	`conversions` bigint NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `campaigns_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `credits` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`balance` decimal(12,2) NOT NULL DEFAULT '0.00',
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `credits_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `media_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(256) NOT NULL,
	`type` enum('image','video','document') NOT NULL DEFAULT 'image',
	`mimeType` varchar(128),
	`size` bigint NOT NULL DEFAULT 0,
	`storageKey` text NOT NULL,
	`url` text NOT NULL,
	`thumbnailUrl` text,
	`tags` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `media_files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`type` enum('campaign_started','campaign_ended','low_credits','topup_success','campaign_alert','system') NOT NULL,
	`title` varchar(256) NOT NULL,
	`message` text NOT NULL,
	`isRead` boolean NOT NULL DEFAULT false,
	`relatedId` int,
	`relatedType` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `social_connections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`platform` enum('meta','tiktok','youtube') NOT NULL,
	`accountId` varchar(256),
	`accountName` varchar(256),
	`accessToken` text,
	`refreshToken` text,
	`tokenExpiresAt` timestamp,
	`isActive` boolean NOT NULL DEFAULT false,
	`connectedAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `social_connections_id` PRIMARY KEY(`id`)
);
