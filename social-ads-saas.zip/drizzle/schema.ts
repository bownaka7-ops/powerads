import {
  bigint,
  boolean,
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Credits
export const credits = mysqlTable("credits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0.00").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Credit = typeof credits.$inferSelect;

// Billing / Top-up transactions
export const billingTransactions = mysqlTable("billing_transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["topup", "spend", "refund"]).notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["pending", "completed", "failed"]).default("completed").notNull(),
  paymentMethod: varchar("paymentMethod", { length: 64 }),
  referenceId: varchar("referenceId", { length: 128 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BillingTransaction = typeof billingTransactions.$inferSelect;

// Campaigns
export const campaigns = mysqlTable("campaigns", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 256 }).notNull(),
  description: text("description"),
  objective: mysqlEnum("objective", ["awareness", "traffic", "engagement", "leads", "sales"]).default("awareness").notNull(),
  status: mysqlEnum("status", ["draft", "active", "paused", "completed", "archived"]).default("draft").notNull(),
  platform: mysqlEnum("platform", ["meta", "tiktok", "youtube", "all"]).default("meta").notNull(),
  budget: decimal("budget", { precision: 12, scale: 2 }).default("0.00").notNull(),
  spent: decimal("spent", { precision: 12, scale: 2 }).default("0.00").notNull(),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  targetAudience: text("targetAudience"),
  impressions: bigint("impressions", { mode: "number" }).default(0).notNull(),
  clicks: bigint("clicks", { mode: "number" }).default(0).notNull(),
  conversions: bigint("conversions", { mode: "number" }).default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Campaign = typeof campaigns.$inferSelect;
export type InsertCampaign = typeof campaigns.$inferInsert;

// Ads (within campaigns)
export const ads = mysqlTable("ads", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 256 }).notNull(),
  type: mysqlEnum("type", ["image", "video", "carousel", "story"]).default("image").notNull(),
  status: mysqlEnum("status", ["draft", "active", "paused", "archived"]).default("draft").notNull(),
  mediaUrl: text("mediaUrl"),
  headline: varchar("headline", { length: 256 }),
  body: text("body"),
  callToAction: varchar("callToAction", { length: 64 }),
  destinationUrl: text("destinationUrl"),
  impressions: bigint("impressions", { mode: "number" }).default(0).notNull(),
  clicks: bigint("clicks", { mode: "number" }).default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Ad = typeof ads.$inferSelect;

// Media Files
export const mediaFiles = mysqlTable("media_files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 256 }).notNull(),
  type: mysqlEnum("type", ["image", "video", "document"]).default("image").notNull(),
  mimeType: varchar("mimeType", { length: 128 }),
  size: bigint("size", { mode: "number" }).default(0).notNull(),
  storageKey: text("storageKey").notNull(),
  url: text("url").notNull(),
  thumbnailUrl: text("thumbnailUrl"),
  tags: text("tags"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type MediaFile = typeof mediaFiles.$inferSelect;

// Social Media Connections
export const socialConnections = mysqlTable("social_connections", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  platform: mysqlEnum("platform", ["meta", "tiktok", "youtube"]).notNull(),
  accountId: varchar("accountId", { length: 256 }),
  accountName: varchar("accountName", { length: 256 }),
  accessToken: text("accessToken"),
  refreshToken: text("refreshToken"),
  tokenExpiresAt: timestamp("tokenExpiresAt"),
  isActive: boolean("isActive").default(false).notNull(),
  connectedAt: timestamp("connectedAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type SocialConnection = typeof socialConnections.$inferSelect;

// Notifications
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", ["campaign_started", "campaign_ended", "low_credits", "topup_success", "campaign_alert", "system"]).notNull(),
  title: varchar("title", { length: 256 }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false).notNull(),
  relatedId: int("relatedId"),
  relatedType: varchar("relatedType", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;

// Analytics snapshots (daily)
export const analyticsSnapshots = mysqlTable("analytics_snapshots", {
  id: int("id").autoincrement().primaryKey(),
  campaignId: int("campaignId").notNull(),
  userId: int("userId").notNull(),
  date: timestamp("date").notNull(),
  impressions: bigint("impressions", { mode: "number" }).default(0).notNull(),
  clicks: bigint("clicks", { mode: "number" }).default(0).notNull(),
  conversions: bigint("conversions", { mode: "number" }).default(0).notNull(),
  spend: decimal("spend", { precision: 12, scale: 2 }).default("0.00").notNull(),
  ctr: decimal("ctr", { precision: 6, scale: 4 }).default("0.0000"),
  cpc: decimal("cpc", { precision: 10, scale: 4 }).default("0.0000"),
  roas: decimal("roas", { precision: 10, scale: 4 }).default("0.0000"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalyticsSnapshot = typeof analyticsSnapshots.$inferSelect;
