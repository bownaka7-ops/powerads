import { and, desc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  ads,
  analyticsSnapshots,
  billingTransactions,
  campaigns,
  credits,
  mediaFiles,
  notifications,
  socialConnections,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── Users ────────────────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    textFields.forEach((field) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    });
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Credits ──────────────────────────────────────────────────────────────────

export async function getUserCredit(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(credits).where(eq(credits.userId, userId)).limit(1);
  if (result.length > 0) return result[0];
  // Auto-create credit record
  await db.insert(credits).values({ userId, balance: "0.00" });
  const created = await db.select().from(credits).where(eq(credits.userId, userId)).limit(1);
  return created[0] ?? null;
}

export async function addCredits(userId: number, amount: number, description: string, paymentMethod?: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(billingTransactions).values({
    userId,
    type: "topup",
    amount: amount.toFixed(2),
    description,
    status: "completed",
    paymentMethod: paymentMethod ?? "manual",
    referenceId: `TXN-${Date.now()}`,
  });
  const existing = await getUserCredit(userId);
  if (existing) {
    const newBalance = (Number(existing.balance) + amount).toFixed(2);
    await db.update(credits).set({ balance: newBalance }).where(eq(credits.userId, userId));
  } else {
    await db.insert(credits).values({ userId, balance: amount.toFixed(2) });
  }
}

export async function deductCredits(userId: number, amount: number, description: string) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const credit = await getUserCredit(userId);
  if (!credit || Number(credit.balance) < amount) throw new Error("Insufficient credits");
  const newBalance = (Number(credit.balance) - amount).toFixed(2);
  await db.update(credits).set({ balance: newBalance }).where(eq(credits.userId, userId));
  await db.insert(billingTransactions).values({
    userId,
    type: "spend",
    amount: amount.toFixed(2),
    description,
    status: "completed",
  });
}

// ─── Billing ──────────────────────────────────────────────────────────────────

export async function getBillingHistory(userId: number, limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(billingTransactions)
    .where(eq(billingTransactions.userId, userId))
    .orderBy(desc(billingTransactions.createdAt))
    .limit(limit)
    .offset(offset);
}

// ─── Campaigns ────────────────────────────────────────────────────────────────

export async function getCampaigns(userId: number, limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(campaigns)
    .where(eq(campaigns.userId, userId))
    .orderBy(desc(campaigns.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function getCampaignById(id: number, userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(campaigns)
    .where(and(eq(campaigns.id, id), eq(campaigns.userId, userId)))
    .limit(1);
  return result[0] ?? null;
}

export async function createCampaign(data: {
  userId: number;
  name: string;
  description?: string;
  objective: "awareness" | "traffic" | "engagement" | "leads" | "sales";
  platform: "meta" | "tiktok" | "youtube" | "all";
  budget: number;
  startDate?: Date;
  endDate?: Date;
  targetAudience?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(campaigns).values({
    ...data,
    budget: data.budget.toFixed(2),
    spent: "0.00",
    status: "draft",
  });
  return result;
}

export async function updateCampaignStatus(
  id: number,
  userId: number,
  status: "draft" | "active" | "paused" | "completed" | "archived"
) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .update(campaigns)
    .set({ status })
    .where(and(eq(campaigns.id, id), eq(campaigns.userId, userId)));
}

export async function getCampaignAds(campaignId: number, userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(ads)
    .where(and(eq(ads.campaignId, campaignId), eq(ads.userId, userId)))
    .orderBy(desc(ads.createdAt));
}

// ─── Analytics ────────────────────────────────────────────────────────────────

export async function getDashboardStats(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const credit = await getUserCredit(userId);
  const allCampaigns = await db
    .select()
    .from(campaigns)
    .where(eq(campaigns.userId, userId));
  const activeCampaigns = allCampaigns.filter((c) => c.status === "active").length;
  const totalImpressions = allCampaigns.reduce((sum, c) => sum + (c.impressions ?? 0), 0);
  const totalClicks = allCampaigns.reduce((sum, c) => sum + (c.clicks ?? 0), 0);
  const totalConversions = allCampaigns.reduce((sum, c) => sum + (c.conversions ?? 0), 0);
  const totalSpent = allCampaigns.reduce((sum, c) => sum + Number(c.spent ?? 0), 0);
  return {
    creditBalance: credit?.balance ?? "0.00",
    activeCampaigns,
    totalCampaigns: allCampaigns.length,
    totalImpressions,
    totalClicks,
    totalConversions,
    totalSpent,
  };
}

export async function getAnalyticsData(userId: number, campaignId?: number) {
  const db = await getDb();
  if (!db) return [];
  const conditions = campaignId
    ? and(eq(analyticsSnapshots.userId, userId), eq(analyticsSnapshots.campaignId, campaignId))
    : eq(analyticsSnapshots.userId, userId);
  return db
    .select()
    .from(analyticsSnapshots)
    .where(conditions)
    .orderBy(desc(analyticsSnapshots.date))
    .limit(30);
}

// ─── Media Files ──────────────────────────────────────────────────────────────

export async function getMediaFiles(userId: number, limit = 20, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(mediaFiles)
    .where(eq(mediaFiles.userId, userId))
    .orderBy(desc(mediaFiles.createdAt))
    .limit(limit)
    .offset(offset);
}

export async function createMediaFile(data: {
  userId: number;
  name: string;
  type: "image" | "video" | "document";
  mimeType?: string;
  size: number;
  storageKey: string;
  url: string;
  tags?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(mediaFiles).values(data);
  return result;
}

export async function deleteMediaFile(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.delete(mediaFiles).where(and(eq(mediaFiles.id, id), eq(mediaFiles.userId, userId)));
}

// ─── Social Connections ───────────────────────────────────────────────────────

export async function getSocialConnections(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(socialConnections)
    .where(eq(socialConnections.userId, userId));
}

export async function upsertSocialConnection(data: {
  userId: number;
  platform: "meta" | "tiktok" | "youtube";
  accountId?: string;
  accountName?: string;
  isActive: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const existing = await db
    .select()
    .from(socialConnections)
    .where(and(eq(socialConnections.userId, data.userId), eq(socialConnections.platform, data.platform)))
    .limit(1);
  if (existing.length > 0) {
    await db
      .update(socialConnections)
      .set({ accountId: data.accountId, accountName: data.accountName, isActive: data.isActive })
      .where(and(eq(socialConnections.userId, data.userId), eq(socialConnections.platform, data.platform)));
  } else {
    await db.insert(socialConnections).values(data);
  }
}

export async function disconnectSocialConnection(userId: number, platform: "meta" | "tiktok" | "youtube") {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db
    .update(socialConnections)
    .set({ isActive: false, accountId: null, accountName: null, accessToken: null })
    .where(and(eq(socialConnections.userId, userId), eq(socialConnections.platform, platform)));
}

// ─── Notifications ────────────────────────────────────────────────────────────

export async function getUserNotifications(userId: number, limit = 20, unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];
  const conditions = unreadOnly
    ? and(eq(notifications.userId, userId), eq(notifications.isRead, false))
    : eq(notifications.userId, userId);
  return db
    .select()
    .from(notifications)
    .where(conditions)
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}

export async function createNotification(data: {
  userId: number;
  type: "campaign_started" | "campaign_ended" | "low_credits" | "topup_success" | "campaign_alert" | "system";
  title: string;
  message: string;
  relatedId?: number;
  relatedType?: string;
}) {
  const db = await getDb();
  if (!db) return;
  await db.insert(notifications).values(data);
}

export async function markNotificationRead(id: number, userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(notifications)
    .set({ isRead: true })
    .where(and(eq(notifications.id, id), eq(notifications.userId, userId)));
}

export async function markAllNotificationsRead(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(notifications)
    .set({ isRead: true })
    .where(eq(notifications.userId, userId));
}

export async function getUnreadNotificationCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return result[0]?.count ?? 0;
}
