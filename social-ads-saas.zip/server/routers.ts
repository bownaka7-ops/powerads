import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  addCredits,
  createCampaign,
  createMediaFile,
  createNotification,
  deductCredits,
  deleteMediaFile,
  disconnectSocialConnection,
  getAnalyticsData,
  getBillingHistory,
  getCampaignAds,
  getCampaignById,
  getCampaigns,
  getDashboardStats,
  getMediaFiles,
  getSocialConnections,
  getUnreadNotificationCount,
  getUserCredit,
  getUserNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  updateCampaignStatus,
  upsertSocialConnection,
} from "./db";
import { storagePut } from "./storage";

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Dashboard ──────────────────────────────────────────────────────────────
  dashboard: router({
    stats: protectedProcedure.query(async ({ ctx }) => {
      return getDashboardStats(ctx.user.id);
    }),
  }),

  // ─── Credits ────────────────────────────────────────────────────────────────
  credits: router({
    balance: protectedProcedure.query(async ({ ctx }) => {
      return getUserCredit(ctx.user.id);
    }),
    topup: protectedProcedure
      .input(
        z.object({
          amount: z.number().min(100).max(100000),
          paymentMethod: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await addCredits(ctx.user.id, input.amount, `Top-up ฿${input.amount}`, input.paymentMethod);
        await createNotification({
          userId: ctx.user.id,
          type: "topup_success",
          title: "Credit Top-up Successful",
          message: `฿${input.amount.toLocaleString()} has been added to your account.`,
        });
        // Notify owner
        await notifyOwner({
          title: "New Credit Top-up",
          content: `User ${ctx.user.name ?? ctx.user.openId} topped up ฿${input.amount.toLocaleString()}.`,
        });
        return { success: true };
      }),
    history: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        return getBillingHistory(ctx.user.id, input.limit, input.offset);
      }),
  }),

  // ─── Campaigns ──────────────────────────────────────────────────────────────
  campaigns: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        return getCampaigns(ctx.user.id, input.limit, input.offset);
      }),
    get: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ ctx, input }) => {
        return getCampaignById(input.id, ctx.user.id);
      }),
    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(256),
          description: z.string().optional(),
          objective: z.enum(["awareness", "traffic", "engagement", "leads", "sales"]),
          platform: z.enum(["meta", "tiktok", "youtube", "all"]),
          budget: z.number().min(0),
          startDate: z.string().optional(),
          endDate: z.string().optional(),
          targetAudience: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await createCampaign({
          userId: ctx.user.id,
          name: input.name,
          description: input.description,
          objective: input.objective,
          platform: input.platform,
          budget: input.budget,
          startDate: input.startDate ? new Date(input.startDate) : undefined,
          endDate: input.endDate ? new Date(input.endDate) : undefined,
          targetAudience: input.targetAudience,
        });
        await createNotification({
          userId: ctx.user.id,
          type: "system",
          title: "Campaign Created",
          message: `Campaign "${input.name}" has been created successfully.`,
        });
        await notifyOwner({
          title: "New Campaign Created",
          content: `User ${ctx.user.name ?? ctx.user.openId} created campaign "${input.name}" on ${input.platform}.`,
        });
        return { success: true };
      }),
    updateStatus: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["draft", "active", "paused", "completed", "archived"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await updateCampaignStatus(input.id, ctx.user.id, input.status);
        if (input.status === "active") {
          await createNotification({
            userId: ctx.user.id,
            type: "campaign_started",
            title: "Campaign Activated",
            message: `Your campaign has been activated and is now running.`,
            relatedId: input.id,
            relatedType: "campaign",
          });
        }
        return { success: true };
      }),
    ads: protectedProcedure
      .input(z.object({ campaignId: z.number() }))
      .query(async ({ ctx, input }) => {
        return getCampaignAds(input.campaignId, ctx.user.id);
      }),
  }),

  // ─── Analytics ──────────────────────────────────────────────────────────────
  analytics: router({
    data: protectedProcedure
      .input(z.object({ campaignId: z.number().optional() }))
      .query(async ({ ctx, input }) => {
        return getAnalyticsData(ctx.user.id, input.campaignId);
      }),
  }),

  // ─── Media ──────────────────────────────────────────────────────────────────
  media: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ ctx, input }) => {
        return getMediaFiles(ctx.user.id, input.limit, input.offset);
      }),
    upload: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          type: z.enum(["image", "video", "document"]),
          mimeType: z.string().optional(),
          size: z.number(),
          base64: z.string(),
          tags: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const buffer = Buffer.from(input.base64, "base64");
        const key = `media/${ctx.user.id}/${Date.now()}-${input.name}`;
        const { url } = await storagePut(key, buffer, input.mimeType ?? "application/octet-stream");
        await createMediaFile({
          userId: ctx.user.id,
          name: input.name,
          type: input.type,
          mimeType: input.mimeType,
          size: input.size,
          storageKey: key,
          url,
          tags: input.tags,
        });
        return { success: true, url };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await deleteMediaFile(input.id, ctx.user.id);
        return { success: true };
      }),
  }),

  // ─── Settings / Social Connections ──────────────────────────────────────────
  settings: router({
    socialConnections: protectedProcedure.query(async ({ ctx }) => {
      return getSocialConnections(ctx.user.id);
    }),
    connectSocial: protectedProcedure
      .input(
        z.object({
          platform: z.enum(["meta", "tiktok", "youtube"]),
          accountId: z.string().optional(),
          accountName: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await upsertSocialConnection({
          userId: ctx.user.id,
          platform: input.platform,
          accountId: input.accountId,
          accountName: input.accountName,
          isActive: true,
        });
        await notifyOwner({
          title: "Social Account Connected",
          content: `User ${ctx.user.name ?? ctx.user.openId} connected ${input.platform} account${input.accountName ? ` (${input.accountName})` : ""}.`,
        });
        return { success: true };
      }),
    disconnectSocial: protectedProcedure
      .input(z.object({ platform: z.enum(["meta", "tiktok", "youtube"]) }))
      .mutation(async ({ ctx, input }) => {
        await disconnectSocialConnection(ctx.user.id, input.platform);
        return { success: true };
      }),
  }),

  // ─── Notifications ──────────────────────────────────────────────────────────
  notifications: router({
    list: protectedProcedure
      .input(z.object({ limit: z.number().default(20), unreadOnly: z.boolean().default(false) }))
      .query(async ({ ctx, input }) => {
        return getUserNotifications(ctx.user.id, input.limit, input.unreadOnly);
      }),
    unreadCount: protectedProcedure.query(async ({ ctx }) => {
      return getUnreadNotificationCount(ctx.user.id);
    }),
    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await markNotificationRead(input.id, ctx.user.id);
        return { success: true };
      }),
    markAllRead: protectedProcedure.mutation(async ({ ctx }) => {
      await markAllNotificationsRead(ctx.user.id);
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
