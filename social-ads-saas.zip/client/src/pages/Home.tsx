import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";
import {
  BarChart3,
  Zap,
  Target,
  TrendingUp,
  Shield,
  Globe,
  ArrowRight,
  Play,
  CheckCircle,
  Star,
} from "lucide-react";
import { useEffect } from "react";

const features = [
  {
    icon: Target,
    title: "Multi-Platform Campaigns",
    desc: "Manage Meta, TikTok, and YouTube ads from a single unified dashboard.",
    color: "oklch(0.65 0.22 265)",
  },
  {
    icon: BarChart3,
    title: "Real-Time Analytics",
    desc: "Track impressions, clicks, conversions, and ROAS with live data visualization.",
    color: "oklch(0.72 0.18 200)",
  },
  {
    icon: Zap,
    title: "Credit System",
    desc: "Flexible credit-based billing. Top up anytime, spend only what you need.",
    color: "oklch(0.78 0.16 80)",
  },
  {
    icon: TrendingUp,
    title: "Performance Reports",
    desc: "Comprehensive reports with actionable insights to optimize your ad spend.",
    color: "oklch(0.75 0.18 150)",
  },
  {
    icon: Shield,
    title: "Secure & Reliable",
    desc: "Enterprise-grade security with OAuth authentication and encrypted data.",
    color: "oklch(0.65 0.22 320)",
  },
  {
    icon: Globe,
    title: "Media Gallery",
    desc: "Centralized media management for all your ad creatives and assets.",
    color: "oklch(0.70 0.20 50)",
  },
];

const stats = [
  { value: "10M+", label: "Ad Impressions" },
  { value: "50K+", label: "Campaigns Managed" },
  { value: "3", label: "Platforms Supported" },
  { value: "99.9%", label: "Uptime SLA" },
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (isAuthenticated) {
      navigate("/dashboard");
    }
  }, [isAuthenticated, navigate]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg gradient-brand flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-lg" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              AdFlow
            </span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#features" className="hover:text-foreground transition-colors">Features</a>
            <a href="#stats" className="hover:text-foreground transition-colors">Stats</a>
            <a href="#pricing" className="hover:text-foreground transition-colors">Pricing</a>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.location.href = getLoginUrl()}
              className="text-muted-foreground hover:text-foreground"
            >
              Sign In
            </Button>
            <Button
              size="sm"
              onClick={() => window.location.href = getLoginUrl()}
              className="gradient-brand text-white border-0 glow-primary"
            >
              Get Started
              <ArrowRight className="w-3.5 h-3.5 ml-1" />
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-24 overflow-hidden">
        {/* Background glow effects */}
        <div
          className="absolute top-20 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full opacity-20 blur-3xl pointer-events-none"
          style={{ background: "radial-gradient(ellipse, oklch(0.65 0.22 265), transparent)" }}
        />
        <div
          className="absolute top-40 right-0 w-[400px] h-[400px] rounded-full opacity-10 blur-3xl pointer-events-none"
          style={{ background: "radial-gradient(ellipse, oklch(0.65 0.22 320), transparent)" }}
        />

        <div className="container relative">
          <div className="max-w-4xl mx-auto text-center">
            <Badge
              className="mb-6 border-primary/30 bg-primary/10 text-primary px-4 py-1.5"
              variant="outline"
            >
              <Star className="w-3 h-3 mr-1.5 fill-current" />
              The Ultimate Ad Management Platform
            </Badge>

            <h1
              className="text-5xl md:text-7xl font-bold mb-6 leading-tight tracking-tight"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Supercharge Your{" "}
              <span className="gradient-text">Social Ads</span>
              <br />
              with AI-Powered Insights
            </h1>

            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              Manage campaigns across Meta, TikTok, and YouTube from one powerful platform.
              Real-time analytics, smart budgeting, and effortless scaling.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                size="lg"
                onClick={() => window.location.href = getLoginUrl()}
                className="gradient-brand text-white border-0 glow-primary px-8 h-12 text-base font-semibold"
              >
                Start Free Today
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="px-8 h-12 text-base border-border/60 hover:bg-secondary"
              >
                <Play className="w-4 h-4 mr-2 fill-current" />
                Watch Demo
              </Button>
            </div>

            <div className="mt-8 flex items-center justify-center gap-6 text-sm text-muted-foreground">
              {["No credit card required", "Free 14-day trial", "Cancel anytime"].map((item) => (
                <div key={item} className="flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5 text-primary" />
                  {item}
                </div>
              ))}
            </div>
          </div>

          {/* Dashboard Preview */}
          <div className="mt-20 relative max-w-5xl mx-auto">
            <div
              className="absolute inset-0 rounded-2xl blur-xl opacity-30 pointer-events-none"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 265 / 0.4), oklch(0.65 0.22 320 / 0.4))" }}
            />
            <div className="relative glass-card rounded-2xl p-1 border border-primary/20">
              <div className="bg-card rounded-xl p-6 space-y-4">
                {/* Mock dashboard header */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full bg-destructive" />
                    <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.78 0.16 80)" }} />
                    <div className="w-3 h-3 rounded-full" style={{ background: "oklch(0.75 0.18 150)" }} />
                  </div>
                  <div className="text-xs text-muted-foreground">AdFlow Dashboard</div>
                </div>
                {/* Mock stats row */}
                <div className="grid grid-cols-4 gap-3">
                  {[
                    { label: "Total Spend", value: "฿24,580", change: "+12%" },
                    { label: "Impressions", value: "1.2M", change: "+8%" },
                    { label: "Clicks", value: "48.2K", change: "+23%" },
                    { label: "Conversions", value: "1,840", change: "+15%" },
                  ].map((stat) => (
                    <div key={stat.label} className="bg-secondary/50 rounded-lg p-3">
                      <div className="text-xs text-muted-foreground mb-1">{stat.label}</div>
                      <div className="font-bold text-sm">{stat.value}</div>
                      <div className="text-xs" style={{ color: "oklch(0.75 0.18 150)" }}>{stat.change}</div>
                    </div>
                  ))}
                </div>
                {/* Mock chart */}
                <div className="bg-secondary/30 rounded-lg h-32 flex items-end justify-around px-4 pb-3 gap-1">
                  {[40, 65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 88].map((h, i) => (
                    <div
                      key={i}
                      className="rounded-sm w-full"
                      style={{
                        height: `${h}%`,
                        background: i % 3 === 0
                          ? "oklch(0.65 0.22 265)"
                          : i % 3 === 1
                          ? "oklch(0.72 0.18 200)"
                          : "oklch(0.65 0.22 320)",
                        opacity: 0.7 + (i / 12) * 0.3,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section id="stats" className="py-16 border-y border-border/50">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div
                  className="text-4xl font-bold mb-2"
                  style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.75 0.22 265)" }}
                >
                  {stat.value}
                </div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24">
        <div className="container">
          <div className="text-center mb-16">
            <Badge className="mb-4 border-primary/30 bg-primary/10 text-primary" variant="outline">
              Features
            </Badge>
            <h2
              className="text-4xl font-bold mb-4"
              style={{ fontFamily: "'Space Grotesk', sans-serif" }}
            >
              Everything You Need to{" "}
              <span className="gradient-text">Scale Your Ads</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              A complete toolkit for modern advertisers who demand performance, insights, and control.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="glass-card rounded-xl p-6 hover:border-primary/30 transition-all duration-300 group"
              >
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center mb-4"
                  style={{ background: `${feature.color}20`, border: `1px solid ${feature.color}30` }}
                >
                  <feature.icon className="w-5 h-5" style={{ color: feature.color }} />
                </div>
                <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="pricing" className="py-24">
        <div className="container">
          <div className="relative max-w-3xl mx-auto text-center">
            <div
              className="absolute inset-0 rounded-3xl blur-2xl opacity-20 pointer-events-none"
              style={{ background: "linear-gradient(135deg, oklch(0.65 0.22 265), oklch(0.65 0.22 320))" }}
            />
            <div className="relative glass-card rounded-3xl p-12 border-primary/20">
              <h2
                className="text-4xl font-bold mb-4"
                style={{ fontFamily: "'Space Grotesk', sans-serif" }}
              >
                Ready to{" "}
                <span className="gradient-text">Get Started?</span>
              </h2>
              <p className="text-muted-foreground mb-8 text-lg">
                Join thousands of advertisers who trust AdFlow to manage their campaigns.
              </p>
              <Button
                size="lg"
                onClick={() => window.location.href = getLoginUrl()}
                className="gradient-brand text-white border-0 glow-primary px-10 h-12 text-base font-semibold"
              >
                Start Free with Manus OAuth
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <p className="mt-4 text-xs text-muted-foreground">
                Secure login via Manus OAuth — no password required
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-8">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded gradient-brand flex items-center justify-center">
              <Zap className="w-3 h-3 text-white" />
            </div>
            <span className="font-semibold text-sm" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              AdFlow
            </span>
          </div>
          <p className="text-xs text-muted-foreground">
            © 2026 AdFlow. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
