import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  Bell,
  BellOff,
  CheckCheck,
  CreditCard,
  Megaphone,
  Settings,
  TriangleAlert,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

const typeConfig: Record<string, { icon: React.ElementType; color: string; label: string }> = {
  campaign_started: { icon: Megaphone, color: "oklch(0.75 0.18 150)", label: "Campaign Started" },
  campaign_ended: { icon: Megaphone, color: "oklch(0.55 0.02 260)", label: "Campaign Ended" },
  low_credits: { icon: TriangleAlert, color: "oklch(0.78 0.16 80)", label: "Low Credits" },
  topup_success: { icon: CreditCard, color: "oklch(0.75 0.18 150)", label: "Top-up Success" },
  campaign_alert: { icon: TriangleAlert, color: "oklch(0.55 0.22 25)", label: "Campaign Alert" },
  system: { icon: Settings, color: "oklch(0.65 0.22 265)", label: "System" },
};

export default function Notifications() {
  const utils = trpc.useUtils();

  const { data: notifications, isLoading, refetch } = trpc.notifications.list.useQuery({
    limit: 50,
    unreadOnly: false,
  });

  const markRead = trpc.notifications.markRead.useMutation({
    onSuccess: () => { refetch(); utils.notifications.unreadCount.invalidate(); },
  });

  const markAllRead = trpc.notifications.markAllRead.useMutation({
    onSuccess: () => {
      refetch();
      utils.notifications.unreadCount.invalidate();
      toast.success("All notifications marked as read");
    },
  });

  const unreadCount = (notifications ?? []).filter((n) => !n.isRead).length;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Notifications
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {unreadCount > 0 ? `${unreadCount} unread` : "All caught up"}
            </p>
          </div>
          {unreadCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              className="border-border text-sm gap-2"
              onClick={() => markAllRead.mutate()}
              disabled={markAllRead.isPending}
            >
              <CheckCheck className="w-4 h-4" />
              Mark all read
            </Button>
          )}
        </div>

        {/* Notification List */}
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />
                ))}
              </div>
            ) : !notifications || notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 text-center">
                <BellOff className="w-12 h-12 text-muted-foreground/20 mb-4" />
                <h3 className="font-semibold text-lg mb-2">No notifications</h3>
                <p className="text-sm text-muted-foreground">
                  You'll see campaign alerts, credit updates, and system messages here.
                </p>
              </div>
            ) : (
              <div>
                {notifications.map((notification, index) => {
                  const config = typeConfig[notification.type] ?? typeConfig.system;
                  const Icon = config.icon;
                  return (
                    <div
                      key={notification.id}
                      className={`flex items-start gap-4 p-4 cursor-pointer hover:bg-secondary/20 transition-colors ${
                        index < notifications.length - 1 ? "border-b border-border/50" : ""
                      } ${!notification.isRead ? "bg-primary/5" : ""}`}
                      onClick={() => !notification.isRead && markRead.mutate({ id: notification.id })}
                    >
                      <div
                        className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0 mt-0.5"
                        style={{ background: `${config.color}20` }}
                      >
                        <Icon className="w-4 h-4" style={{ color: config.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <span className="font-medium text-sm">{notification.title}</span>
                          {!notification.isRead && (
                            <span
                              className="w-1.5 h-1.5 rounded-full shrink-0"
                              style={{ background: "oklch(0.65 0.22 265)" }}
                            />
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{notification.message}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(notification.createdAt).toLocaleString("th-TH")}
                        </p>
                      </div>
                      <Badge
                        variant="outline"
                        className="text-xs shrink-0 border-border/50"
                        style={{ color: config.color }}
                      >
                        {config.label}
                      </Badge>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
