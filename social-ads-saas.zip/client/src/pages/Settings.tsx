import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import {
  CheckCircle,
  ExternalLink,
  Link2,
  Link2Off,
  Settings as SettingsIcon,
  User,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const platforms = [
  {
    id: "meta" as const,
    name: "Meta",
    fullName: "Meta (Facebook & Instagram)",
    color: "oklch(0.65 0.22 265)",
    description: "Connect your Facebook and Instagram ad accounts to manage campaigns directly.",
    features: ["Facebook Ads", "Instagram Ads", "Audience Insights", "Pixel Tracking"],
  },
  {
    id: "tiktok" as const,
    name: "TikTok",
    fullName: "TikTok for Business",
    color: "oklch(0.72 0.18 200)",
    description: "Connect your TikTok Business account to run and manage TikTok ad campaigns.",
    features: ["TikTok Ads", "Spark Ads", "TopView", "Brand Takeover"],
  },
  {
    id: "youtube" as const,
    name: "YouTube",
    fullName: "YouTube / Google Ads",
    color: "oklch(0.55 0.22 25)",
    description: "Connect your Google Ads account to manage YouTube video campaigns.",
    features: ["YouTube Ads", "Skippable Ads", "Bumper Ads", "Discovery Ads"],
  },
];

export default function Settings() {
  const { user } = useAuth();
  const [connectingPlatform, setConnectingPlatform] = useState<string | null>(null);
  const [accountInputs, setAccountInputs] = useState<Record<string, { id: string; name: string }>>({
    meta: { id: "", name: "" },
    tiktok: { id: "", name: "" },
    youtube: { id: "", name: "" },
  });

  const { data: connections, refetch } = trpc.settings.socialConnections.useQuery();
  const connectMutation = trpc.settings.connectSocial.useMutation({
    onSuccess: () => {
      refetch();
      setConnectingPlatform(null);
      toast.success("Account connected successfully!");
    },
    onError: (e) => toast.error(e.message),
  });
  const disconnectMutation = trpc.settings.disconnectSocial.useMutation({
    onSuccess: () => { refetch(); toast.success("Account disconnected"); },
    onError: (e) => toast.error(e.message),
  });

  const getConnection = (platform: string) =>
    connections?.find((c) => c.platform === platform && c.isActive);

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Settings
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage your account and integrations</p>
        </div>

        {/* Profile */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <User className="w-4 h-4 text-primary" />
              Account Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold"
                style={{ background: "oklch(0.65 0.22 265 / 0.2)", color: "oklch(0.65 0.22 265)" }}
              >
                {user?.name?.charAt(0)?.toUpperCase() ?? "U"}
              </div>
              <div>
                <p className="font-semibold">{user?.name ?? "User"}</p>
                <p className="text-sm text-muted-foreground">{user?.email ?? "—"}</p>
                <Badge variant="outline" className="text-xs border-border text-muted-foreground mt-1 capitalize">
                  {user?.role ?? "user"}
                </Badge>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Display Name</Label>
                <Input value={user?.name ?? ""} readOnly className="bg-secondary/30 border-border text-sm" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Email</Label>
                <Input value={user?.email ?? ""} readOnly className="bg-secondary/30 border-border text-sm" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Profile information is managed through your Manus account.
            </p>
          </CardContent>
        </Card>

        {/* Social Connections */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Link2 className="w-4 h-4 text-primary" />
              Social Media Connections
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {platforms.map((platform) => {
              const connection = getConnection(platform.id);
              const isConnecting = connectingPlatform === platform.id;

              return (
                <div
                  key={platform.id}
                  className="p-4 rounded-xl border border-border bg-secondary/10 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm"
                        style={{ background: `${platform.color}20`, color: platform.color }}
                      >
                        {platform.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{platform.fullName}</span>
                          {connection && (
                            <CheckCircle className="w-3.5 h-3.5" style={{ color: "oklch(0.75 0.18 150)" }} />
                          )}
                        </div>
                        {connection ? (
                          <p className="text-xs text-muted-foreground">
                            Connected: {connection.accountName ?? connection.accountId ?? "Account"}
                          </p>
                        ) : (
                          <p className="text-xs text-muted-foreground">Not connected</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {connection ? (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-xs border-border text-red-400 hover:text-red-300"
                          onClick={() => disconnectMutation.mutate({ platform: platform.id })}
                          disabled={disconnectMutation.isPending}
                        >
                          <Link2Off className="w-3 h-3 mr-1.5" />
                          Disconnect
                        </Button>
                      ) : (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-xs border-border"
                          onClick={() => setConnectingPlatform(isConnecting ? null : platform.id)}
                        >
                          <Link2 className="w-3 h-3 mr-1.5" />
                          Connect
                        </Button>
                      )}
                    </div>
                  </div>

                  {/* Features */}
                  <div className="flex flex-wrap gap-1.5">
                    {platform.features.map((f) => (
                      <Badge
                        key={f}
                        variant="outline"
                        className="text-xs border-border/50 text-muted-foreground"
                      >
                        {f}
                      </Badge>
                    ))}
                  </div>

                  {/* Connect Form */}
                  {isConnecting && !connection && (
                    <div className="pt-2 border-t border-border space-y-3">
                      <p className="text-xs text-muted-foreground">{platform.description}</p>
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1.5">
                          <Label className="text-xs">Account ID</Label>
                          <Input
                            placeholder="e.g., act_123456789"
                            value={accountInputs[platform.id]?.id ?? ""}
                            onChange={(e) =>
                              setAccountInputs((prev) => ({
                                ...prev,
                                [platform.id]: { ...prev[platform.id]!, id: e.target.value },
                              }))
                            }
                            className="bg-secondary/30 border-border text-sm h-8"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label className="text-xs">Account Name</Label>
                          <Input
                            placeholder="e.g., My Business"
                            value={accountInputs[platform.id]?.name ?? ""}
                            onChange={(e) =>
                              setAccountInputs((prev) => ({
                                ...prev,
                                [platform.id]: { ...prev[platform.id]!, name: e.target.value },
                              }))
                            }
                            className="bg-secondary/30 border-border text-sm h-8"
                          />
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="gradient-brand text-white border-0 h-8 text-xs"
                          onClick={() =>
                            connectMutation.mutate({
                              platform: platform.id,
                              accountId: accountInputs[platform.id]?.id || undefined,
                              accountName: accountInputs[platform.id]?.name || undefined,
                            })
                          }
                          disabled={connectMutation.isPending}
                        >
                          {connectMutation.isPending ? "Connecting..." : "Save Connection"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 text-xs"
                          onClick={() => setConnectingPlatform(null)}
                        >
                          Cancel
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        This is a demo platform. In production, OAuth flow would redirect to {platform.name}.
                      </p>
                    </div>
                  )}
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* App Settings */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <SettingsIcon className="w-4 h-4 text-primary" />
              App Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { label: "Notification Alerts", desc: "Receive alerts for campaign events" },
              { label: "Low Credit Warning", desc: "Alert when balance drops below ฿500" },
              { label: "Weekly Reports", desc: "Receive weekly performance summaries" },
            ].map((setting) => (
              <div key={setting.label} className="flex items-center justify-between p-3 rounded-lg bg-secondary/20">
                <div>
                  <p className="text-sm font-medium">{setting.label}</p>
                  <p className="text-xs text-muted-foreground">{setting.desc}</p>
                </div>
                <button
                  className="w-10 h-5 rounded-full relative transition-colors"
                  style={{ background: "oklch(0.65 0.22 265)" }}
                  onClick={() => toast.info("Settings saved")}
                >
                  <span className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow" />
                </button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
