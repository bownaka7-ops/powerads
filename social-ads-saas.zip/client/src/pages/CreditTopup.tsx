import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { trpc } from "@/lib/trpc";
import { CheckCircle, CreditCard, Wallet, Zap } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const presetAmounts = [500, 1000, 2000, 5000, 10000, 20000];

const paymentMethods = [
  { value: "credit_card", label: "Credit / Debit Card", icon: CreditCard },
  { value: "bank_transfer", label: "Bank Transfer", icon: Wallet },
  { value: "promptpay", label: "PromptPay", icon: Zap },
];

export default function CreditTopup() {
  const [amount, setAmount] = useState("");
  const [customAmount, setCustomAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("credit_card");
  const [success, setSuccess] = useState(false);

  const { data: credit, refetch } = trpc.credits.balance.useQuery();
  const topup = trpc.credits.topup.useMutation({
    onSuccess: () => {
      setSuccess(true);
      refetch();
      toast.success("Credits added successfully!");
    },
    onError: (e) => toast.error(e.message),
  });

  const selectedAmount = customAmount ? Number(customAmount) : Number(amount);

  const handleTopup = () => {
    if (!selectedAmount || selectedAmount < 100) {
      return toast.error("Minimum top-up amount is ฿100");
    }
    topup.mutate({ amount: selectedAmount, paymentMethod });
  };

  if (success) {
    return (
      <DashboardLayout>
        <div className="max-w-md mx-auto flex flex-col items-center justify-center py-20 text-center">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
            style={{ background: "oklch(0.75 0.18 150 / 0.2)" }}
          >
            <CheckCircle className="w-8 h-8" style={{ color: "oklch(0.75 0.18 150)" }} />
          </div>
          <h2 className="text-2xl font-bold mb-2" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Top-up Successful!
          </h2>
          <p className="text-muted-foreground mb-2">
            ฿{selectedAmount.toLocaleString()} has been added to your account.
          </p>
          <p className="text-sm text-muted-foreground mb-8">
            New balance: ฿{Number(credit?.balance ?? 0).toLocaleString()}
          </p>
          <Button
            onClick={() => { setSuccess(false); setAmount(""); setCustomAmount(""); }}
            className="gradient-brand text-white border-0 glow-primary"
          >
            Top Up Again
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Credit Top-up
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Add credits to your account</p>
        </div>

        {/* Current Balance */}
        <Card className="bg-card border-border">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Current Balance</p>
                <p className="text-3xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  ฿{Number(credit?.balance ?? 0).toLocaleString()}
                </p>
              </div>
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center"
                style={{ background: "oklch(0.65 0.22 265 / 0.15)", border: "1px solid oklch(0.65 0.22 265 / 0.3)" }}
              >
                <Wallet className="w-7 h-7" style={{ color: "oklch(0.65 0.22 265)" }} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Amount Selection */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Select Amount</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              {presetAmounts.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => { setAmount(String(preset)); setCustomAmount(""); }}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    amount === String(preset) && !customAmount
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-secondary/20 hover:border-border/80 text-foreground"
                  }`}
                >
                  <div className="font-semibold text-sm">฿{preset.toLocaleString()}</div>
                </button>
              ))}
            </div>
            <div className="space-y-2">
              <Label>Custom Amount (฿)</Label>
              <Input
                type="number"
                placeholder="Enter custom amount (min ฿100)"
                min="100"
                value={customAmount}
                onChange={(e) => { setCustomAmount(e.target.value); setAmount(""); }}
                className="bg-secondary/30 border-border"
              />
            </div>
            {selectedAmount > 0 && (
              <div className="flex items-center justify-between p-3 rounded-lg bg-primary/10 border border-primary/20">
                <span className="text-sm text-muted-foreground">You will add</span>
                <span className="font-bold text-primary">฿{selectedAmount.toLocaleString()}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Payment Method</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {paymentMethods.map((method) => (
              <button
                key={method.value}
                type="button"
                onClick={() => setPaymentMethod(method.value)}
                className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all ${
                  paymentMethod === method.value
                    ? "border-primary bg-primary/10"
                    : "border-border bg-secondary/20 hover:border-border/80"
                }`}
              >
                <div
                  className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                  style={{
                    background: paymentMethod === method.value ? "oklch(0.65 0.22 265 / 0.2)" : "oklch(0.18 0.02 260)",
                  }}
                >
                  <method.icon
                    className="w-4 h-4"
                    style={{ color: paymentMethod === method.value ? "oklch(0.65 0.22 265)" : "oklch(0.55 0.02 260)" }}
                  />
                </div>
                <span className="font-medium text-sm">{method.label}</span>
                {paymentMethod === method.value && (
                  <CheckCircle className="w-4 h-4 ml-auto" style={{ color: "oklch(0.65 0.22 265)" }} />
                )}
              </button>
            ))}
            <p className="text-xs text-muted-foreground text-center pt-1">
              This is a demo platform. No actual payment will be processed.
            </p>
          </CardContent>
        </Card>

        {/* Submit */}
        <Button
          onClick={handleTopup}
          disabled={topup.isPending || !selectedAmount || selectedAmount < 100}
          className="w-full gradient-brand text-white border-0 glow-primary h-12 text-base font-semibold"
        >
          {topup.isPending ? "Processing..." : `Add ฿${selectedAmount > 0 ? selectedAmount.toLocaleString() : "—"} Credits`}
        </Button>
      </div>
    </DashboardLayout>
  );
}
