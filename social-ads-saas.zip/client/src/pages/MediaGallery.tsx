import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  FileImage,
  FileText,
  FileVideo,
  Grid3X3,
  List,
  Trash2,
  Upload,
} from "lucide-react";
import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";

const typeIcons = {
  image: FileImage,
  video: FileVideo,
  document: FileText,
};

const typeColors = {
  image: "oklch(0.65 0.22 265)",
  video: "oklch(0.72 0.18 200)",
  document: "oklch(0.78 0.16 80)",
};

function formatBytes(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function MediaGallery() {
  const [view, setView] = useState<"grid" | "list">("grid");
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: files, isLoading, refetch } = trpc.media.list.useQuery({ limit: 50, offset: 0 });
  const uploadMutation = trpc.media.upload.useMutation({
    onSuccess: () => { refetch(); toast.success("File uploaded successfully"); },
    onError: (e) => toast.error(e.message),
  });
  const deleteMutation = trpc.media.delete.useMutation({
    onSuccess: () => { refetch(); toast.success("File deleted"); },
    onError: (e) => toast.error(e.message),
  });

  const handleFiles = useCallback(async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    try {
      for (const file of Array.from(fileList)) {
        if (file.size > 10 * 1024 * 1024) {
          toast.error(`${file.name} exceeds 10MB limit`);
          continue;
        }
        const reader = new FileReader();
        const base64 = await new Promise<string>((resolve, reject) => {
          reader.onload = () => resolve((reader.result as string).split(",")[1] ?? "");
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        const type = file.type.startsWith("image/")
          ? "image"
          : file.type.startsWith("video/")
          ? "video"
          : "document";
        await uploadMutation.mutateAsync({
          name: file.name,
          type,
          mimeType: file.type,
          size: file.size,
          base64,
        });
      }
    } finally {
      setUploading(false);
    }
  }, [uploadMutation]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Media Gallery
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {files?.length ?? 0} files stored
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center border border-border rounded-lg overflow-hidden">
              <button
                onClick={() => setView("grid")}
                className={`p-2 transition-colors ${view === "grid" ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Grid3X3 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setView("list")}
                className={`p-2 transition-colors ${view === "list" ? "bg-primary/20 text-primary" : "text-muted-foreground hover:text-foreground"}`}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
            <Button
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="gradient-brand text-white border-0 glow-primary"
            >
              <Upload className="w-4 h-4 mr-2" />
              {uploading ? "Uploading..." : "Upload"}
            </Button>
            <input
              ref={fileRef}
              type="file"
              multiple
              accept="image/*,video/*,.pdf,.doc,.docx"
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
          </div>
        </div>

        {/* Drop Zone */}
        <div
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          onClick={() => fileRef.current?.click()}
          className="border-2 border-dashed border-border rounded-xl p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/5 transition-all"
        >
          <Upload className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">
            Drag & drop files here, or <span className="text-primary">click to browse</span>
          </p>
          <p className="text-xs text-muted-foreground mt-1">Images, videos, documents up to 10MB</p>
        </div>

        {/* Files */}
        {isLoading ? (
          <div className={view === "grid" ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4" : "space-y-2"}>
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className={`bg-card rounded-xl animate-pulse ${view === "grid" ? "h-36" : "h-16"}`} />
            ))}
          </div>
        ) : !files || files.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <FileImage className="w-12 h-12 text-muted-foreground/20 mb-4" />
            <h3 className="font-semibold text-lg mb-2">No files yet</h3>
            <p className="text-sm text-muted-foreground">Upload images, videos, and documents for your campaigns</p>
          </div>
        ) : view === "grid" ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {files.map((file) => {
              const Icon = typeIcons[file.type] ?? FileText;
              const color = typeColors[file.type] ?? "oklch(0.55 0.02 260)";
              return (
                <Card key={file.id} className="bg-card border-border group overflow-hidden">
                  <CardContent className="p-0">
                    {/* Preview */}
                    <div
                      className="h-28 flex items-center justify-center relative"
                      style={{ background: `${color}10` }}
                    >
                      {file.type === "image" ? (
                        <img src={file.url} alt={file.name} className="w-full h-full object-cover" />
                      ) : (
                        <Icon className="w-10 h-10" style={{ color }} />
                      )}
                      {/* Delete overlay */}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <button
                          onClick={() => deleteMutation.mutate({ id: file.id })}
                          className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/40 transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="text-xs font-medium truncate">{file.name}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{formatBytes(file.size)}</p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="space-y-2">
            {files.map((file) => {
              const Icon = typeIcons[file.type] ?? FileText;
              const color = typeColors[file.type] ?? "oklch(0.55 0.02 260)";
              return (
                <div
                  key={file.id}
                  className="flex items-center gap-4 p-4 bg-card rounded-xl border border-border hover:border-border/80 transition-colors group"
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0"
                    style={{ background: `${color}20` }}
                  >
                    <Icon className="w-5 h-5" style={{ color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {formatBytes(file.size)} · {new Date(file.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant="outline" className="text-xs border-border text-muted-foreground capitalize">
                    {file.type}
                  </Badge>
                  <button
                    onClick={() => deleteMutation.mutate({ id: file.id })}
                    className="opacity-0 group-hover:opacity-100 p-2 rounded-lg hover:bg-red-500/20 transition-all"
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
