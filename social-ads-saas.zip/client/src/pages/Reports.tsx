import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  BarChart3,
  Download,
  FileText,
  TrendingDown,
  TrendingUp,
  Users,
} from "lucide-react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const mockReportData = [
  { campaign: "Summer Sale", impressions: 45200, clicks: 1808, ctr: 4.0, conversions: 90, roas: 3.2, spend: 4520 },
  { campaign: "Brand Awareness Q2", impressions: 88000, clicks: 2640, ctr: 3.0, conversions: 52, roas: 1.8, spend: 8800 },
  { campaign: "TikTok Launch", impressions: 62000, clicks: 2790, ctr: 4.5, conversions: 139, roas: 4.1, spend: 6200 },
  { campaign: "YouTube Promo", impressions: 31000, clicks: 930, ctr: 3.0, conversions: 46, roas: 2.5, spend: 3100 },
  { campaign: "Retargeting Dec", impressions: 18500, clicks: 925, ctr: 5.0, conversions: 92, roas: 5.8, spend: 1850 },
];

const mockWeeklyROAS = [
  { week: "W1", roas: 2.1 },
  { week: "W2", roas: 2.8 },
  { week: "W3", roas: 3.2 },
  { week: "W4", roas: 2.9 },
  { week: "W5", roas: 3.8 },
  { week: "W6", roas: 4.1 },
  { week: "W7", roas: 3.6 },
  { week: "W8", roas: 4.5 },
];

const tooltipStyle = {
  contentStyle: {
    background: "oklch(0.12 0.015 260)",
    border: "1px solid oklch(0.22 0.02 260)",
    borderRadius: "8px",
    fontSize: "12px",
  },
};

export default function Reports() {
  const { data: campaigns } = trpc.campaigns.list.useQuery({ limit: 50, offset: 0 });

  const totalImpressions = mockReportData.reduce((s, r) => s + r.impressions, 0);
  const totalClicks = mockReportData.reduce((s, r) => s + r.clicks, 0);
  const totalConversions = mockReportData.reduce((s, r) => s + r.conversions, 0);
  const totalSpend = mockReportData.reduce((s, r) => s + r.spend, 0);
  const avgROAS = (mockReportData.reduce((s, r) => s + r.roas, 0) / mockReportData.length).toFixed(2);
  const avgCTR = ((totalClicks / totalImpressions) * 100).toFixed(2);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Performance Reports
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">Detailed campaign performance analysis</p>
          </div>
          <Button variant="outline" className="border-border text-sm gap-2">
            <Download className="w-4 h-4" />
            Export CSV
          </Button>
        </div>

        {/* Summary KPIs */}
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { label: "Total Impressions", value: `${(totalImpressions / 1000).toFixed(1)}K`, icon: Users, color: "oklch(0.65 0.22 265)", trend: "+15%" },
            { label: "Total Clicks", value: `${(totalClicks / 1000).toFixed(1)}K`, icon: BarChart3, color: "oklch(0.72 0.18 200)", trend: "+22%" },
            { label: "Avg. CTR", value: `${avgCTR}%`, icon: TrendingUp, color: "oklch(0.75 0.18 150)", trend: "+0.4%" },
            { label: "Total Conversions", value: totalConversions.toLocaleString(), icon: FileText, color: "oklch(0.78 0.16 80)", trend: "+31%" },
            { label: "Total Spend", value: `฿${totalSpend.toLocaleString()}`, icon: TrendingDown, color: "oklch(0.55 0.22 25)", trend: "+8%" },
            { label: "Avg. ROAS", value: `${avgROAS}x`, icon: TrendingUp, color: "oklch(0.65 0.22 320)", trend: "+0.6x" },
          ].map((kpi) => (
            <Card key={kpi.label} className="bg-card border-border">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${kpi.color}20` }}>
                    <kpi.icon className="w-3.5 h-3.5" style={{ color: kpi.color }} />
                  </div>
                  <span className="text-xs text-muted-foreground">{kpi.label}</span>
                </div>
                <div className="text-xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{kpi.value}</div>
                <div className="text-xs mt-0.5" style={{ color: "oklch(0.75 0.18 150)" }}>{kpi.trend} vs last period</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* ROAS Trend */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">ROAS Trend (8 Weeks)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={mockWeeklyROAS} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <Tooltip {...tooltipStyle} />
                <Line
                  type="monotone"
                  dataKey="roas"
                  name="ROAS"
                  stroke="oklch(0.65 0.22 320)"
                  strokeWidth={2.5}
                  dot={{ fill: "oklch(0.65 0.22 320)", r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Campaign Comparison */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Campaign Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={mockReportData} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                <XAxis
                  dataKey="campaign"
                  tick={{ fontSize: 10, fill: "oklch(0.55 0.02 260)" }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v: string) => v.length > 12 ? v.slice(0, 12) + "…" : v}
                />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="conversions" name="Conversions" radius={[4, 4, 0, 0]}>
                  {mockReportData.map((_, i) => (
                    <Cell key={i} fill={["oklch(0.65 0.22 265)", "oklch(0.72 0.18 200)", "oklch(0.75 0.18 150)", "oklch(0.78 0.16 80)", "oklch(0.65 0.22 320)"][i % 5]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Detailed Table */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Campaign Performance Table</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    {["Campaign", "Impressions", "Clicks", "CTR", "Conversions", "ROAS", "Spend"].map((h) => (
                      <th key={h} className="text-left py-3 px-2 text-xs text-muted-foreground font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {mockReportData.map((row, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-secondary/20 transition-colors">
                      <td className="py-3 px-2 font-medium">{row.campaign}</td>
                      <td className="py-3 px-2 text-muted-foreground">{row.impressions.toLocaleString()}</td>
                      <td className="py-3 px-2 text-muted-foreground">{row.clicks.toLocaleString()}</td>
                      <td className="py-3 px-2">
                        <Badge
                          variant="outline"
                          className="text-xs"
                          style={{
                            borderColor: row.ctr >= 4 ? "oklch(0.75 0.18 150 / 0.4)" : "oklch(0.55 0.02 260 / 0.4)",
                            color: row.ctr >= 4 ? "oklch(0.75 0.18 150)" : "oklch(0.55 0.02 260)",
                          }}
                        >
                          {row.ctr}%
                        </Badge>
                      </td>
                      <td className="py-3 px-2 text-muted-foreground">{row.conversions}</td>
                      <td className="py-3 px-2">
                        <span style={{ color: row.roas >= 3 ? "oklch(0.75 0.18 150)" : "oklch(0.78 0.16 80)" }}>
                          {row.roas}x
                        </span>
                      </td>
                      <td className="py-3 px-2 text-muted-foreground">฿{row.spend.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
