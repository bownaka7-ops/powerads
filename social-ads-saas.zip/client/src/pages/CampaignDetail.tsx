import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  ArrowLeft,
  BarChart3,
  Calendar,
  DollarSign,
  Megaphone,
  MousePointerClick,
  Pause,
  Play,
  TrendingUp,
  Users,
} from "lucide-react";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const mockDailyData = [
  { day: "Day 1", impressions: 4200, clicks: 168, spend: 420 },
  { day: "Day 3", impressions: 6800, clicks: 272, spend: 680 },
  { day: "Day 5", impressions: 5500, clicks: 220, spend: 550 },
  { day: "Day 7", impressions: 9200, clicks: 368, spend: 920 },
  { day: "Day 10", impressions: 11000, clicks: 440, spend: 1100 },
  { day: "Day 14", impressions: 8800, clicks: 352, spend: 880 },
];

const statusColors: Record<string, string> = {
  active: "oklch(0.75 0.18 150)",
  paused: "oklch(0.78 0.16 80)",
  draft: "oklch(0.55 0.02 260)",
  completed: "oklch(0.65 0.22 265)",
  archived: "oklch(0.45 0.02 260)",
};

const platformColors: Record<string, string> = {
  meta: "oklch(0.65 0.22 265)",
  tiktok: "oklch(0.72 0.18 200)",
  youtube: "oklch(0.55 0.22 25)",
  all: "oklch(0.65 0.22 320)",
};

export default function CampaignDetail() {
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id ?? "0");

  const { data: campaign, isLoading, refetch } = trpc.campaigns.get.useQuery({ id });
  const updateStatus = trpc.campaigns.updateStatus.useMutation({
    onSuccess: () => { refetch(); toast.success("Status updated"); },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="space-y-4">
          <div className="h-8 w-48 bg-muted rounded animate-pulse" />
          <div className="h-32 bg-card rounded-xl animate-pulse" />
          <div className="grid grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-24 bg-card rounded-xl animate-pulse" />
            ))}
          </div>
        </div>
      </DashboardLayout>
    );
  }

  if (!campaign) {
    return (
      <DashboardLayout>
        <div className="flex flex-col items-center justify-center py-20">
          <Megaphone className="w-12 h-12 text-muted-foreground/20 mb-4" />
          <h3 className="font-semibold text-lg mb-2">Campaign not found</h3>
          <Button variant="ghost" onClick={() => navigate("/campaigns")}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Campaigns
          </Button>
        </div>
      </DashboardLayout>
    );
  }

  const ctr = campaign.impressions > 0 ? ((campaign.clicks / campaign.impressions) * 100).toFixed(2) : "0.00";
  const budgetUsed = Number(campaign.budget) > 0 ? ((Number(campaign.spent) / Number(campaign.budget)) * 100).toFixed(0) : "0";

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/campaigns")} className="h-8 w-8 p-0">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {campaign.name}
                </h1>
                <Badge
                  variant="outline"
                  style={{
                    borderColor: `${statusColors[campaign.status] ?? "oklch(0.55 0.02 260)"}50`,
                    color: statusColors[campaign.status] ?? "oklch(0.55 0.02 260)",
                  }}
                >
                  {campaign.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-0.5 capitalize">
                {campaign.platform} · {campaign.objective}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {campaign.status === "draft" && (
              <Button
                size="sm"
                className="gradient-brand text-white border-0"
                onClick={() => updateStatus.mutate({ id: campaign.id, status: "active" })}
              >
                <Play className="w-3.5 h-3.5 mr-1.5" />
                Activate
              </Button>
            )}
            {campaign.status === "active" && (
              <Button
                size="sm"
                variant="outline"
                className="border-border"
                onClick={() => updateStatus.mutate({ id: campaign.id, status: "paused" })}
              >
                <Pause className="w-3.5 h-3.5 mr-1.5" />
                Pause
              </Button>
            )}
            {campaign.status === "paused" && (
              <Button
                size="sm"
                className="gradient-brand text-white border-0"
                onClick={() => updateStatus.mutate({ id: campaign.id, status: "active" })}
              >
                <Play className="w-3.5 h-3.5 mr-1.5" />
                Resume
              </Button>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Impressions", value: campaign.impressions.toLocaleString(), icon: Users, color: "oklch(0.65 0.22 265)" },
            { label: "Clicks", value: campaign.clicks.toLocaleString(), icon: MousePointerClick, color: "oklch(0.72 0.18 200)" },
            { label: "CTR", value: `${ctr}%`, icon: TrendingUp, color: "oklch(0.75 0.18 150)" },
            { label: "Conversions", value: campaign.conversions.toLocaleString(), icon: BarChart3, color: "oklch(0.78 0.16 80)" },
          ].map((stat) => (
            <Card key={stat.label} className="bg-card border-border">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-2">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center"
                    style={{ background: `${stat.color}20` }}
                  >
                    <stat.icon className="w-3.5 h-3.5" style={{ color: stat.color }} />
                  </div>
                  <span className="text-xs text-muted-foreground">{stat.label}</span>
                </div>
                <div className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {stat.value}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Budget Progress + Details */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Chart */}
          <Card className="lg:col-span-2 bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Daily Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <AreaChart data={mockDailyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="impGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.65 0.22 265)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.65 0.22 265)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      background: "oklch(0.12 0.015 260)",
                      border: "1px solid oklch(0.22 0.02 260)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                  />
                  <Area type="monotone" dataKey="impressions" stroke="oklch(0.65 0.22 265)" strokeWidth={2} fill="url(#impGrad)" />
                  <Area type="monotone" dataKey="clicks" stroke="oklch(0.72 0.18 200)" strokeWidth={2} fill="none" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Details */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Campaign Info</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Budget */}
              <div>
                <div className="flex items-center justify-between text-sm mb-2">
                  <span className="text-muted-foreground flex items-center gap-1.5">
                    <DollarSign className="w-3.5 h-3.5" />
                    Budget Used
                  </span>
                  <span className="font-semibold">{budgetUsed}%</span>
                </div>
                <div className="h-2 bg-secondary rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${Math.min(Number(budgetUsed), 100)}%`,
                      background: Number(budgetUsed) > 80 ? "oklch(0.55 0.22 25)" : "oklch(0.65 0.22 265)",
                    }}
                  />
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-1">
                  <span>฿{Number(campaign.spent).toLocaleString()} spent</span>
                  <span>฿{Number(campaign.budget).toLocaleString()} total</span>
                </div>
              </div>

              {/* Info rows */}
              {[
                { icon: Calendar, label: "Start", value: campaign.startDate ? new Date(campaign.startDate).toLocaleDateString() : "Not set" },
                { icon: Calendar, label: "End", value: campaign.endDate ? new Date(campaign.endDate).toLocaleDateString() : "Not set" },
                { icon: Megaphone, label: "Platform", value: campaign.platform.charAt(0).toUpperCase() + campaign.platform.slice(1) },
                { icon: TrendingUp, label: "Objective", value: campaign.objective.charAt(0).toUpperCase() + campaign.objective.slice(1) },
              ].map((row) => (
                <div key={row.label} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground flex items-center gap-1.5">
                    <row.icon className="w-3.5 h-3.5" />
                    {row.label}
                  </span>
                  <span className="font-medium">{row.value}</span>
                </div>
              ))}

              {campaign.description && (
                <div className="pt-2 border-t border-border">
                  <p className="text-xs text-muted-foreground">{campaign.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
