import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import {
  ArrowUpRight,
  BarChart3,
  Filter,
  Megaphone,
  MousePointerClick,
  PlusCircle,
  Search,
  TrendingUp,
  Users,
} from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const platformColors: Record<string, string> = {
  meta: "oklch(0.65 0.22 265)",
  tiktok: "oklch(0.72 0.18 200)",
  youtube: "oklch(0.55 0.22 25)",
  all: "oklch(0.65 0.22 320)",
};

const statusColors: Record<string, string> = {
  active: "oklch(0.75 0.18 150)",
  paused: "oklch(0.78 0.16 80)",
  draft: "oklch(0.55 0.02 260)",
  completed: "oklch(0.65 0.22 265)",
  archived: "oklch(0.45 0.02 260)",
};

const platformIcons: Record<string, string> = {
  meta: "M",
  tiktok: "T",
  youtube: "Y",
  all: "A",
};

export default function Campaigns() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [platformFilter, setPlatformFilter] = useState("all");

  const { data: campaigns, isLoading, refetch } = trpc.campaigns.list.useQuery({ limit: 50, offset: 0 });
  const updateStatus = trpc.campaigns.updateStatus.useMutation({
    onSuccess: () => {
      refetch();
      toast.success("Campaign status updated");
    },
    onError: (e) => toast.error(e.message),
  });

  const filtered = (campaigns ?? []).filter((c) => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || c.status === statusFilter;
    const matchPlatform = platformFilter === "all" || c.platform === platformFilter;
    return matchSearch && matchStatus && matchPlatform;
  });

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Campaigns
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              {campaigns?.length ?? 0} total campaigns
            </p>
          </div>
          <Button
            onClick={() => navigate("/create-campaign")}
            className="gradient-brand text-white border-0 glow-primary"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            New Campaign
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search campaigns..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 bg-card border-border"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-40 bg-card border-border">
              <Filter className="w-3.5 h-3.5 mr-2 text-muted-foreground" />
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>
          <Select value={platformFilter} onValueChange={setPlatformFilter}>
            <SelectTrigger className="w-full sm:w-40 bg-card border-border">
              <SelectValue placeholder="Platform" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Platforms</SelectItem>
              <SelectItem value="meta">Meta</SelectItem>
              <SelectItem value="tiktok">TikTok</SelectItem>
              <SelectItem value="youtube">YouTube</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Campaign List */}
        {isLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-24 bg-card rounded-xl animate-pulse" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Megaphone className="w-12 h-12 text-muted-foreground/20 mb-4" />
            <h3 className="font-semibold text-lg mb-2">No campaigns found</h3>
            <p className="text-sm text-muted-foreground mb-6">
              {campaigns?.length === 0
                ? "Get started by creating your first campaign."
                : "Try adjusting your search or filters."}
            </p>
            {campaigns?.length === 0 && (
              <Button onClick={() => navigate("/create-campaign")} className="gradient-brand text-white border-0">
                <PlusCircle className="w-4 h-4 mr-2" />
                Create Campaign
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            {filtered.map((campaign) => (
              <Card
                key={campaign.id}
                className="bg-card border-border hover:border-primary/30 transition-all cursor-pointer group"
                onClick={() => navigate(`/campaigns/${campaign.id}`)}
              >
                <CardContent className="p-5">
                  <div className="flex items-center gap-4">
                    {/* Platform icon */}
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-bold text-sm"
                      style={{
                        background: `${platformColors[campaign.platform] ?? "oklch(0.65 0.22 265)"}20`,
                        border: `1px solid ${platformColors[campaign.platform] ?? "oklch(0.65 0.22 265)"}30`,
                        color: platformColors[campaign.platform] ?? "oklch(0.65 0.22 265)",
                      }}
                    >
                      {platformIcons[campaign.platform] ?? "A"}
                    </div>

                    {/* Campaign info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold truncate group-hover:text-primary transition-colors">
                          {campaign.name}
                        </h3>
                        <Badge
                          variant="outline"
                          className="text-xs shrink-0"
                          style={{
                            borderColor: `${statusColors[campaign.status] ?? "oklch(0.55 0.02 260)"}50`,
                            color: statusColors[campaign.status] ?? "oklch(0.55 0.02 260)",
                          }}
                        >
                          {campaign.status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="capitalize">{campaign.platform}</span>
                        <span>•</span>
                        <span className="capitalize">{campaign.objective}</span>
                        <span>•</span>
                        <span>Budget: ฿{Number(campaign.budget).toLocaleString()}</span>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="hidden md:flex items-center gap-6 text-sm">
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-muted-foreground text-xs mb-0.5">
                          <Users className="w-3 h-3" />
                          Impressions
                        </div>
                        <div className="font-semibold">{(campaign.impressions / 1000).toFixed(1)}K</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-muted-foreground text-xs mb-0.5">
                          <MousePointerClick className="w-3 h-3" />
                          Clicks
                        </div>
                        <div className="font-semibold">{(campaign.clicks / 1000).toFixed(1)}K</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center gap-1 text-muted-foreground text-xs mb-0.5">
                          <TrendingUp className="w-3 h-3" />
                          Spent
                        </div>
                        <div className="font-semibold">฿{Number(campaign.spent).toLocaleString()}</div>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 shrink-0" onClick={(e) => e.stopPropagation()}>
                      {campaign.status === "draft" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-xs border-border"
                          onClick={() => updateStatus.mutate({ id: campaign.id, status: "active" })}
                        >
                          Activate
                        </Button>
                      )}
                      {campaign.status === "active" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-xs border-border"
                          onClick={() => updateStatus.mutate({ id: campaign.id, status: "paused" })}
                        >
                          Pause
                        </Button>
                      )}
                      {campaign.status === "paused" && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-8 text-xs border-border"
                          onClick={() => updateStatus.mutate({ id: campaign.id, status: "active" })}
                        >
                          Resume
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 w-8 p-0"
                        onClick={() => navigate(`/campaigns/${campaign.id}`)}
                      >
                        <ArrowUpRight className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
