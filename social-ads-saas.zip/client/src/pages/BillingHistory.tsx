import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { ArrowDownLeft, ArrowUpRight, Receipt, RefreshCw } from "lucide-react";

const typeConfig = {
  topup: { label: "Top-up", icon: ArrowDownLeft, color: "oklch(0.75 0.18 150)" },
  spend: { label: "Spend", icon: ArrowUpRight, color: "oklch(0.55 0.22 25)" },
  refund: { label: "Refund", icon: RefreshCw, color: "oklch(0.65 0.22 265)" },
};

const statusConfig = {
  completed: { label: "Completed", color: "oklch(0.75 0.18 150)" },
  pending: { label: "Pending", color: "oklch(0.78 0.16 80)" },
  failed: { label: "Failed", color: "oklch(0.55 0.22 25)" },
};

export default function BillingHistory() {
  const { data: transactions, isLoading } = trpc.credits.history.useQuery({ limit: 50, offset: 0 });
  const { data: credit } = trpc.credits.balance.useQuery();

  const totalTopup = (transactions ?? [])
    .filter((t) => t.type === "topup" && t.status === "completed")
    .reduce((sum, t) => sum + Number(t.amount), 0);

  const totalSpent = (transactions ?? [])
    .filter((t) => t.type === "spend" && t.status === "completed")
    .reduce((sum, t) => sum + Number(t.amount), 0);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Billing History
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">All your credit transactions</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {[
            { label: "Current Balance", value: `฿${Number(credit?.balance ?? 0).toLocaleString()}`, color: "oklch(0.65 0.22 265)" },
            { label: "Total Top-up", value: `฿${totalTopup.toLocaleString()}`, color: "oklch(0.75 0.18 150)" },
            { label: "Total Spent", value: `฿${totalSpent.toLocaleString()}`, color: "oklch(0.55 0.22 25)" },
          ].map((card) => (
            <Card key={card.label} className="bg-card border-border">
              <CardContent className="p-5">
                <p className="text-xs text-muted-foreground mb-1">{card.label}</p>
                <p className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif", color: card.color }}>
                  {card.value}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Transactions */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">Transactions</CardTitle>
              <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                {transactions?.length ?? 0} records
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="h-16 bg-muted rounded-lg animate-pulse" />
                ))}
              </div>
            ) : !transactions || transactions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Receipt className="w-10 h-10 text-muted-foreground/20 mb-3" />
                <p className="text-sm text-muted-foreground">No transactions yet</p>
                <p className="text-xs text-muted-foreground mt-1">Top up credits to get started</p>
              </div>
            ) : (
              <div className="space-y-2">
                {transactions.map((tx) => {
                  const config = typeConfig[tx.type] ?? typeConfig.topup;
                  const statusConf = statusConfig[tx.status] ?? statusConfig.completed;
                  const isPositive = tx.type === "topup" || tx.type === "refund";
                  return (
                    <div
                      key={tx.id}
                      className="flex items-center gap-4 p-4 rounded-xl bg-secondary/20 hover:bg-secondary/40 transition-colors"
                    >
                      <div
                        className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                        style={{ background: `${config.color}20` }}
                      >
                        <config.icon className="w-4 h-4" style={{ color: config.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{config.label}</span>
                          <Badge
                            variant="outline"
                            className="text-xs"
                            style={{
                              borderColor: `${statusConf.color}40`,
                              color: statusConf.color,
                            }}
                          >
                            {statusConf.label}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground truncate mt-0.5">
                          {tx.description ?? tx.referenceId ?? "—"}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <div
                          className="font-semibold text-sm"
                          style={{ color: isPositive ? "oklch(0.75 0.18 150)" : "oklch(0.55 0.22 25)" }}
                        >
                          {isPositive ? "+" : "-"}฿{Number(tx.amount).toLocaleString()}
                        </div>
                        <div className="text-xs text-muted-foreground mt-0.5">
                          {new Date(tx.createdAt).toLocaleDateString("th-TH")}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
