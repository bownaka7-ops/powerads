import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { BarChart3, MousePointerClick, TrendingUp, Users } from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const mockTrendData = [
  { month: "Nov", impressions: 45000, clicks: 1800, conversions: 90, spend: 4500 },
  { month: "Dec", impressions: 62000, clicks: 2480, conversions: 124, spend: 6200 },
  { month: "Jan", impressions: 58000, clicks: 2320, conversions: 116, spend: 5800 },
  { month: "Feb", impressions: 75000, clicks: 3000, conversions: 150, spend: 7500 },
  { month: "Mar", impressions: 88000, clicks: 3520, conversions: 176, spend: 8800 },
  { month: "Apr", impressions: 102000, clicks: 4080, conversions: 204, spend: 10200 },
];

const mockPlatformData = [
  { name: "Meta", value: 45, color: "oklch(0.65 0.22 265)" },
  { name: "TikTok", value: 30, color: "oklch(0.72 0.18 200)" },
  { name: "YouTube", value: 25, color: "oklch(0.55 0.22 25)" },
];

const mockObjectiveData = [
  { objective: "Awareness", campaigns: 8, spend: 12000 },
  { objective: "Traffic", campaigns: 5, spend: 8000 },
  { objective: "Engagement", campaigns: 6, spend: 9500 },
  { objective: "Leads", campaigns: 4, spend: 15000 },
  { objective: "Sales", campaigns: 3, spend: 18000 },
];

const mockDailyData = [
  { day: "Mon", ctr: 2.8, cpc: 12.5 },
  { day: "Tue", ctr: 3.2, cpc: 11.8 },
  { day: "Wed", ctr: 2.9, cpc: 13.2 },
  { day: "Thu", ctr: 3.8, cpc: 10.5 },
  { day: "Fri", ctr: 4.1, cpc: 9.8 },
  { day: "Sat", ctr: 3.5, cpc: 11.2 },
  { day: "Sun", ctr: 2.6, cpc: 14.0 },
];

const tooltipStyle = {
  contentStyle: {
    background: "oklch(0.12 0.015 260)",
    border: "1px solid oklch(0.22 0.02 260)",
    borderRadius: "8px",
    fontSize: "12px",
  },
  labelStyle: { color: "oklch(0.85 0.01 260)" },
};

export default function Analytics() {
  const { data: stats } = trpc.dashboard.stats.useQuery();

  const kpiCards = [
    {
      label: "Total Impressions",
      value: stats ? `${((stats.totalImpressions ?? 0) / 1000).toFixed(1)}K` : "—",
      icon: Users,
      color: "oklch(0.65 0.22 265)",
      change: "+12%",
    },
    {
      label: "Total Clicks",
      value: stats ? `${((stats.totalClicks ?? 0) / 1000).toFixed(1)}K` : "—",
      icon: MousePointerClick,
      color: "oklch(0.72 0.18 200)",
      change: "+23%",
    },
    {
      label: "Avg. CTR",
      value: stats && stats.totalImpressions > 0
        ? `${((stats.totalClicks / stats.totalImpressions) * 100).toFixed(2)}%`
        : "—",
      icon: TrendingUp,
      color: "oklch(0.75 0.18 150)",
      change: "+5%",
    },
    {
      label: "Total Conversions",
      value: stats ? (stats.totalConversions ?? 0).toLocaleString() : "—",
      icon: BarChart3,
      color: "oklch(0.78 0.16 80)",
      change: "+18%",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Analytics
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">Campaign performance insights</p>
          </div>
          <Badge variant="outline" className="border-border text-muted-foreground">
            Last 6 months
          </Badge>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {kpiCards.map((card) => (
            <Card key={card.label} className="bg-card border-border">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center"
                    style={{ background: `${card.color}20` }}
                  >
                    <card.icon className="w-4 h-4" style={{ color: card.color }} />
                  </div>
                  <span className="text-xs text-muted-foreground">{card.label}</span>
                </div>
                <div className="text-2xl font-bold mb-1" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {card.value}
                </div>
                <div className="text-xs" style={{ color: "oklch(0.75 0.18 150)" }}>
                  {card.change} vs last period
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trend Chart */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Performance Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={mockTrendData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="impGradA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.65 0.22 265)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.65 0.22 265)" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="clickGradA" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <Tooltip {...tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: "12px", color: "oklch(0.55 0.02 260)" }} />
                <Area type="monotone" dataKey="impressions" name="Impressions" stroke="oklch(0.65 0.22 265)" strokeWidth={2} fill="url(#impGradA)" />
                <Area type="monotone" dataKey="clicks" name="Clicks" stroke="oklch(0.72 0.18 200)" strokeWidth={2} fill="url(#clickGradA)" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Platform Distribution + Objective Spend */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Platform Pie */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Platform Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-6">
                <ResponsiveContainer width={160} height={160}>
                  <PieChart>
                    <Pie
                      data={mockPlatformData}
                      cx="50%"
                      cy="50%"
                      innerRadius={45}
                      outerRadius={70}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {mockPlatformData.map((entry, index) => (
                        <Cell key={index} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "oklch(0.12 0.015 260)",
                        border: "1px solid oklch(0.22 0.02 260)",
                        borderRadius: "8px",
                        fontSize: "12px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
                <div className="space-y-3 flex-1">
                  {mockPlatformData.map((p) => (
                    <div key={p.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 rounded-full" style={{ background: p.color }} />
                        <span className="text-sm">{p.name}</span>
                      </div>
                      <span className="font-semibold text-sm">{p.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* CTR & CPC by day */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">CTR & CPC by Day</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={mockDailyData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                  <Tooltip {...tooltipStyle} />
                  <Bar dataKey="ctr" name="CTR (%)" fill="oklch(0.65 0.22 265)" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="cpc" name="CPC (฿)" fill="oklch(0.72 0.18 200)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Spend by Objective */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Spend by Objective</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={mockObjectiveData} margin={{ top: 5, right: 5, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                <XAxis dataKey="objective" tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="spend" name="Spend (฿)" radius={[4, 4, 0, 0]}>
                  {mockObjectiveData.map((_, index) => (
                    <Cell
                      key={index}
                      fill={[
                        "oklch(0.65 0.22 265)",
                        "oklch(0.72 0.18 200)",
                        "oklch(0.75 0.18 150)",
                        "oklch(0.78 0.16 80)",
                        "oklch(0.65 0.22 320)",
                      ][index % 5]}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
