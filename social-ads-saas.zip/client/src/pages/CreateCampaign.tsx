import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { ArrowLeft, Megaphone, Zap } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const objectives = [
  { value: "awareness", label: "Brand Awareness", desc: "Maximize reach and brand visibility" },
  { value: "traffic", label: "Traffic", desc: "Drive visitors to your website" },
  { value: "engagement", label: "Engagement", desc: "Increase likes, comments, and shares" },
  { value: "leads", label: "Lead Generation", desc: "Collect contact information" },
  { value: "sales", label: "Sales & Conversions", desc: "Drive purchases and conversions" },
];

const platforms = [
  { value: "meta", label: "Meta (Facebook & Instagram)", color: "oklch(0.65 0.22 265)" },
  { value: "tiktok", label: "TikTok", color: "oklch(0.72 0.18 200)" },
  { value: "youtube", label: "YouTube", color: "oklch(0.55 0.22 25)" },
  { value: "all", label: "All Platforms", color: "oklch(0.65 0.22 320)" },
];

export default function CreateCampaign() {
  const [, navigate] = useLocation();
  const [form, setForm] = useState({
    name: "",
    description: "",
    objective: "awareness" as const,
    platform: "meta" as const,
    budget: "",
    startDate: "",
    endDate: "",
    targetAudience: "",
  });

  const createCampaign = trpc.campaigns.create.useMutation({
    onSuccess: () => {
      toast.success("Campaign created successfully!");
      navigate("/campaigns");
    },
    onError: (e) => toast.error(e.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return toast.error("Campaign name is required");
    if (!form.budget || isNaN(Number(form.budget))) return toast.error("Valid budget is required");
    createCampaign.mutate({
      name: form.name,
      description: form.description || undefined,
      objective: form.objective,
      platform: form.platform,
      budget: Number(form.budget),
      startDate: form.startDate || undefined,
      endDate: form.endDate || undefined,
      targetAudience: form.targetAudience || undefined,
    });
  };

  return (
    <DashboardLayout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/campaigns")}
            className="h-8 w-8 p-0"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Create Campaign
            </h1>
            <p className="text-sm text-muted-foreground">Set up a new advertising campaign</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Info */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-primary" />
                Campaign Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Campaign Name *</Label>
                <Input
                  id="name"
                  placeholder="e.g., Summer Sale 2026"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="bg-secondary/30 border-border"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your campaign goals and strategy..."
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="bg-secondary/30 border-border resize-none"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Objective */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Campaign Objective</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {objectives.map((obj) => (
                  <button
                    key={obj.value}
                    type="button"
                    onClick={() => setForm({ ...form, objective: obj.value as typeof form.objective })}
                    className={`text-left p-4 rounded-xl border transition-all ${
                      form.objective === obj.value
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary/20 hover:border-border/80 hover:bg-secondary/40"
                    }`}
                  >
                    <div className="font-medium text-sm mb-1">{obj.label}</div>
                    <div className="text-xs text-muted-foreground">{obj.desc}</div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Platform */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Platform</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {platforms.map((p) => (
                  <button
                    key={p.value}
                    type="button"
                    onClick={() => setForm({ ...form, platform: p.value as typeof form.platform })}
                    className={`text-left p-4 rounded-xl border transition-all ${
                      form.platform === p.value
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary/20 hover:border-border/80"
                    }`}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm mb-2"
                      style={{ background: `${p.color}20`, color: p.color }}
                    >
                      {p.value.charAt(0).toUpperCase()}
                    </div>
                    <div className="font-medium text-sm">{p.label}</div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Budget & Dates */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                Budget & Schedule
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="budget">Total Budget (฿) *</Label>
                <Input
                  id="budget"
                  type="number"
                  placeholder="e.g., 10000"
                  min="0"
                  value={form.budget}
                  onChange={(e) => setForm({ ...form, budget: e.target.value })}
                  className="bg-secondary/30 border-border"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date</Label>
                  <Input
                    id="startDate"
                    type="date"
                    value={form.startDate}
                    onChange={(e) => setForm({ ...form, startDate: e.target.value })}
                    className="bg-secondary/30 border-border"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="endDate">End Date</Label>
                  <Input
                    id="endDate"
                    type="date"
                    value={form.endDate}
                    onChange={(e) => setForm({ ...form, endDate: e.target.value })}
                    className="bg-secondary/30 border-border"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="audience">Target Audience</Label>
                <Textarea
                  id="audience"
                  placeholder="Describe your target audience (age, interests, location)..."
                  value={form.targetAudience}
                  onChange={(e) => setForm({ ...form, targetAudience: e.target.value })}
                  className="bg-secondary/30 border-border resize-none"
                  rows={2}
                />
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="flex gap-3 pb-6">
            <Button
              type="button"
              variant="outline"
              onClick={() => navigate("/campaigns")}
              className="flex-1 border-border"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createCampaign.isPending}
              className="flex-1 gradient-brand text-white border-0 glow-primary"
            >
              {createCampaign.isPending ? "Creating..." : "Create Campaign"}
            </Button>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
}
