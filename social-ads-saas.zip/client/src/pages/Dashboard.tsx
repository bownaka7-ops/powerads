import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import {
  ArrowUpRight,
  BarChart3,
  CreditCard,
  Megaphone,
  MousePointerClick,
  PlusCircle,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import { useLocation } from "wouter";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const mockChartData = [
  { date: "Apr 1", impressions: 12000, clicks: 480, spend: 1200 },
  { date: "Apr 5", impressions: 18000, clicks: 720, spend: 1800 },
  { date: "Apr 10", impressions: 15000, clicks: 600, spend: 1500 },
  { date: "Apr 15", impressions: 22000, clicks: 880, spend: 2200 },
  { date: "Apr 20", impressions: 28000, clicks: 1120, spend: 2800 },
  { date: "Apr 25", impressions: 25000, clicks: 1000, spend: 2500 },
  { date: "Apr 29", impressions: 32000, clicks: 1280, spend: 3200 },
];

const platformColors: Record<string, string> = {
  meta: "oklch(0.65 0.22 265)",
  tiktok: "oklch(0.72 0.18 200)",
  youtube: "oklch(0.55 0.22 25)",
  all: "oklch(0.65 0.22 320)",
};

const statusColors: Record<string, string> = {
  active: "oklch(0.75 0.18 150)",
  paused: "oklch(0.78 0.16 80)",
  draft: "oklch(0.55 0.02 260)",
  completed: "oklch(0.65 0.22 265)",
  archived: "oklch(0.45 0.02 260)",
};

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { data: stats, isLoading: statsLoading } = trpc.dashboard.stats.useQuery();
  const { data: campaigns, isLoading: campaignsLoading } = trpc.campaigns.list.useQuery({ limit: 5, offset: 0 });
  const { data: notifications } = trpc.notifications.list.useQuery({ limit: 3, unreadOnly: false });

  const statCards = [
    {
      title: "Credit Balance",
      value: stats ? `฿${Number(stats.creditBalance).toLocaleString()}` : "—",
      icon: CreditCard,
      change: "+฿5,000",
      changeLabel: "last top-up",
      color: "oklch(0.65 0.22 265)",
      action: () => navigate("/credits"),
      actionLabel: "Top Up",
    },
    {
      title: "Active Campaigns",
      value: stats?.activeCampaigns ?? "—",
      icon: Megaphone,
      change: `${stats?.totalCampaigns ?? 0} total`,
      changeLabel: "campaigns",
      color: "oklch(0.72 0.18 200)",
      action: () => navigate("/campaigns"),
      actionLabel: "View All",
    },
    {
      title: "Total Impressions",
      value: stats ? `${(stats.totalImpressions / 1000).toFixed(1)}K` : "—",
      icon: Users,
      change: "+12%",
      changeLabel: "vs last month",
      color: "oklch(0.75 0.18 150)",
    },
    {
      title: "Total Clicks",
      value: stats ? `${(stats.totalClicks / 1000).toFixed(1)}K` : "—",
      icon: MousePointerClick,
      change: "+23%",
      changeLabel: "vs last month",
      color: "oklch(0.78 0.16 80)",
    },
  ];

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Dashboard
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Welcome back! Here's your campaign overview.
            </p>
          </div>
          <Button
            onClick={() => navigate("/create-campaign")}
            className="gradient-brand text-white border-0 glow-primary"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            New Campaign
          </Button>
        </div>

        {/* Stat Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map((card) => (
            <Card key={card.title} className="bg-card border-border hover:border-primary/30 transition-colors">
              <CardContent className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div
                    className="w-9 h-9 rounded-lg flex items-center justify-center"
                    style={{ background: `${card.color}20`, border: `1px solid ${card.color}30` }}
                  >
                    <card.icon className="w-4 h-4" style={{ color: card.color }} />
                  </div>
                  {card.action && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={card.action}
                      className="h-7 text-xs text-muted-foreground hover:text-foreground px-2"
                    >
                      {card.actionLabel}
                      <ArrowUpRight className="w-3 h-3 ml-1" />
                    </Button>
                  )}
                </div>
                <div className="text-2xl font-bold mb-1" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                  {statsLoading ? (
                    <div className="h-7 w-24 bg-muted rounded animate-pulse" />
                  ) : (
                    card.value
                  )}
                </div>
                <div className="text-xs text-muted-foreground">{card.title}</div>
                <div className="mt-2 flex items-center gap-1 text-xs" style={{ color: "oklch(0.75 0.18 150)" }}>
                  <TrendingUp className="w-3 h-3" />
                  <span>{card.change}</span>
                  <span className="text-muted-foreground">{card.changeLabel}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Chart + Recent Campaigns */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Chart */}
          <Card className="lg:col-span-2 bg-card border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold">Performance Overview</CardTitle>
                <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                  Last 30 days
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={mockChartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="impressionsGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.65 0.22 265)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.65 0.22 265)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="clicksGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="oklch(0.72 0.18 200)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.02 260)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: "oklch(0.55 0.02 260)" }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{
                      background: "oklch(0.12 0.015 260)",
                      border: "1px solid oklch(0.22 0.02 260)",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                    labelStyle={{ color: "oklch(0.85 0.01 260)" }}
                  />
                  <Area type="monotone" dataKey="impressions" stroke="oklch(0.65 0.22 265)" strokeWidth={2} fill="url(#impressionsGrad)" />
                  <Area type="monotone" dataKey="clicks" stroke="oklch(0.72 0.18 200)" strokeWidth={2} fill="url(#clicksGrad)" />
                </AreaChart>
              </ResponsiveContainer>
              <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-0.5 rounded" style={{ background: "oklch(0.65 0.22 265)" }} />
                  Impressions
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-0.5 rounded" style={{ background: "oklch(0.72 0.18 200)" }} />
                  Clicks
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Campaigns */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base font-semibold">Recent Campaigns</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => navigate("/campaigns")}
                  className="h-7 text-xs text-muted-foreground hover:text-foreground px-2"
                >
                  View All
                  <ArrowUpRight className="w-3 h-3 ml-1" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {campaignsLoading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="h-14 bg-muted rounded-lg animate-pulse" />
                ))
              ) : campaigns && campaigns.length > 0 ? (
                campaigns.map((c) => (
                  <div
                    key={c.id}
                    className="flex items-center gap-3 p-3 rounded-lg bg-secondary/30 hover:bg-secondary/60 cursor-pointer transition-colors"
                    onClick={() => navigate(`/campaigns/${c.id}`)}
                  >
                    <div
                      className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                      style={{ background: `${platformColors[c.platform] ?? "oklch(0.65 0.22 265)"}20` }}
                    >
                      <Megaphone className="w-3.5 h-3.5" style={{ color: platformColors[c.platform] ?? "oklch(0.65 0.22 265)" }} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate">{c.name}</div>
                      <div className="text-xs text-muted-foreground capitalize">{c.platform}</div>
                    </div>
                    <Badge
                      variant="outline"
                      className="text-xs shrink-0"
                      style={{
                        borderColor: `${statusColors[c.status] ?? "oklch(0.55 0.02 260)"}50`,
                        color: statusColors[c.status] ?? "oklch(0.55 0.02 260)",
                      }}
                    >
                      {c.status}
                    </Badge>
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Megaphone className="w-8 h-8 text-muted-foreground/30 mb-3" />
                  <p className="text-sm text-muted-foreground">No campaigns yet</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate("/create-campaign")}
                    className="mt-2 text-primary hover:text-primary"
                  >
                    <PlusCircle className="w-3.5 h-3.5 mr-1.5" />
                    Create your first campaign
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { icon: PlusCircle, label: "New Campaign", path: "/create-campaign", color: "oklch(0.65 0.22 265)" },
            { icon: BarChart3, label: "View Analytics", path: "/analytics", color: "oklch(0.72 0.18 200)" },
            { icon: CreditCard, label: "Top Up Credits", path: "/credits", color: "oklch(0.78 0.16 80)" },
            { icon: Zap, label: "Performance", path: "/reports", color: "oklch(0.75 0.18 150)" },
          ].map((action) => (
            <button
              key={action.label}
              onClick={() => navigate(action.path)}
              className="flex items-center gap-3 p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:bg-secondary/30 transition-all text-left group"
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                style={{ background: `${action.color}20`, border: `1px solid ${action.color}30` }}
              >
                <action.icon className="w-4 h-4" style={{ color: action.color }} />
              </div>
              <span className="text-sm font-medium group-hover:text-primary transition-colors">{action.label}</span>
            </button>
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
